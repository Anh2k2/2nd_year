//define
#include<bits/stdc++.h>
using namespace std;

#define pi 3.14159
#define in(x) {printf("Nhap %s = ",#x); scanf("%lf",&x);}
//{cout<<"Nhap "<<#x<<" = "; cin>>x;}
#define out printf
int main()
{
	double anh,ban;
	in(anh);
	in(ban);
	cout<<"Dien tich elipp :"<<pi*anh*ban;

}


