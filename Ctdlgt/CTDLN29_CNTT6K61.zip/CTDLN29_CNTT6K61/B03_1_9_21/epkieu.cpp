#include<bits/stdc++.h>
using namespace std;
int main()
{
	int x=(int)3.5;  //ep kieu cua C
	int y=int(4.6);  //ep kieu C++
	cout<<x<<"  "<<y;

}


