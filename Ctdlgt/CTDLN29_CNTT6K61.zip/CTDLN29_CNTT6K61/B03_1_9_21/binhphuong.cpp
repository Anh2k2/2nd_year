#include<bits/stdc++.h>
using namespace std;
#define bp(x) (x)*(x);
#define MAX(u,v) u>v?(u):(v)
int main()
{
	int a=7;
	double b=5.5;
	cout<<"\nBinh phuong 8 la "<<bp(8);
	cout<<"\nBinh phuong a la "<<bp(a);
	cout<<"\nBinh phuong b la "<<bp(b);
	cout<<"\nBinh phuong cua 3+4 la "<<bp(3+4);  //3+4*3+4
	cout<<"\nMAX(x,y,z)= "<<MAX(MAX(x,y),z)
}


