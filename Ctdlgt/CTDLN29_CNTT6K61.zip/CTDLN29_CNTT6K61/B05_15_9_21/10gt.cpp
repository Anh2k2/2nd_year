#include<bits/stdc++.h>
using namespace std;
int main()
{
	int s=1;						//2
									//2 vao for
	for(int i=1;i<=n;i++) s=s*i; 	//n*4
									//1  ra khoi for
	cout<<s;						//1
}

//T(n)=4n+6=O(n)
