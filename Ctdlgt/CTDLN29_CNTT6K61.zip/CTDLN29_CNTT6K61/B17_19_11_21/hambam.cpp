#include<bits/stdc++.h>
using namespace std;
int main()
{
//	hash<int> H;
//	cout<<H(3433546)<<"\n";
//	cout<<H(-23452)<<"\n";
	hash<string> H;
	cout<<H("hom nay lop nghi tiet dau")<<"\n";
	cout<<H("thay khong vao lop thi dau co tro");

}


