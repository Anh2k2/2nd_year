#include<bits/stdc++.h>
using namespace std;
int main()
{
	int z[1000000];
	cout<<"con co be be";
//	unordered_map<int,int> M;
//1\	for(int x:{4,7,2,8,4,8,3,2,4,6,2,4}) M[x]++;
//	for(auto m:M) cout<<m.first<<" "<<m.second<<"\n";

}


