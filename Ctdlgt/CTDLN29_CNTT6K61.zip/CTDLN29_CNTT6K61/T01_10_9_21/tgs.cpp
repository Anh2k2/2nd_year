#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n=10;
	for(int i=1,j=n;i<=n;i++,j--) cout<<string(j,' ')<<string(i*2-1,'*')<<"\n";
}


