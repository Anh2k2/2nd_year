#include<bits/stdc++.h>
using namespace std;
int main()
{
	int x=3;
	ofstream fout("abc.txt");
	fout<<x;
	fout.close();

}


