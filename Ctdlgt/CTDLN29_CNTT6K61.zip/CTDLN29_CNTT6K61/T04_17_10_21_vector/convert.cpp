#include<bits/stdc++.h>
using namespace std;
int main()
{
	char x[]="hom nay chu nhat";
	string y=x;
	cout<<y;

}


