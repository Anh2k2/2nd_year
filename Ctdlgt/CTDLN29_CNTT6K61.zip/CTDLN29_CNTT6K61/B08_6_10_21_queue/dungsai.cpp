#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a=5;
	if(6<a<10) cout<<"dung";
 	else cout<<"sai";


}


